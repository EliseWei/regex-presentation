// PetProduct constructor goes here

module.exports = {
    PetProduct: PetProduct
}