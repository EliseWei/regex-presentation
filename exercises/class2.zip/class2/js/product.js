// Product constructor goes here

module.exports = {
    Product: Product
}