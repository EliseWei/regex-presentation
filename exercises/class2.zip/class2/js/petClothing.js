var $ = require('jquery');
var petProductModule = require('./petProduct.js');

// PetClothing constructor goes in here

module.exports = {
    PetClothing: PetClothing
}
